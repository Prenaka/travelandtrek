package com.prakash.travelandtrek.service;

import com.prakash.travelandtrek.model.Transaction;
import com.prakash.travelandtrek.repository.TransactionRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransactionServiceImpl implements TransactionService {
    private final TransactionRepository transactionRepository;
    public TransactionServiceImpl(TransactionRepository transactionRepository) {this.transactionRepository = transactionRepository;}

    @Override
    public void saveTransaction(Transaction transaction){
        transactionRepository.save(transaction);
    }

    @Override
    public void updateTransaction(Transaction transaction){transactionRepository.save(transaction);}

    @Override
    public void deleteTransaction(int id){transactionRepository.deleteById(id);}

    @Override
    public Transaction getTransaction(int id){return transactionRepository.findById(id).get();}

    @Override
    public List<Transaction> getAllTransaction(){return transactionRepository.findAll();}
}
