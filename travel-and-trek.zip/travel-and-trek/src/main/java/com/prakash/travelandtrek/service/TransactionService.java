package com.prakash.travelandtrek.service;

import com.prakash.travelandtrek.model.Transaction;

import java.util.List;

public interface TransactionService {
    void saveTransaction(Transaction transaction);

    void updateTransaction(Transaction transaction);

    void deleteTransaction(int id);

    Transaction getTransaction(int id);

    List<Transaction> getAllTransaction();
}
