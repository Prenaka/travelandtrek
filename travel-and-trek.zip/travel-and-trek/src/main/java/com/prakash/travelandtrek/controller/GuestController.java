package com.prakash.travelandtrek.controller;

import com.prakash.travelandtrek.model.Guest;
import com.prakash.travelandtrek.service.GuestServiceImpl;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/guests")
@CrossOrigin(origins = "*")
public class GuestController {

    private final GuestServiceImpl guestService;

    public GuestController(GuestServiceImpl guestService) {
        this.guestService = guestService;
    }

    @PostMapping
    public void saveGuest(@RequestBody Guest guest){
        guestService.saveGuest(guest);
    }

    @PutMapping
    public void updateGuest(@RequestBody Guest guest){ guestService.updateGuest(guest); }

    @DeleteMapping(value = "/{id}")
    public void deleteGuest(@PathVariable int id){
        guestService.deleteGuest(id);
    }

    @GetMapping(value = "/{id}")
    public Guest getGuest(@PathVariable int id){
        return guestService.getGuest(id);
    }

    @GetMapping
    public List<Guest> getAllGuest(){
        return guestService.getAllGuest();
    }



}
