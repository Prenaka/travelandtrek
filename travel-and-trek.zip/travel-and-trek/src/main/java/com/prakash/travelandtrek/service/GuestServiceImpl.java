package com.prakash.travelandtrek.service;

import com.prakash.travelandtrek.model.Guest;
import com.prakash.travelandtrek.repository.GuestRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GuestServiceImpl implements GuestService {

    private final GuestRepository guestRepository;

    public GuestServiceImpl(GuestRepository guestRepository) {this.guestRepository=guestRepository;}

    @Override
    public void saveGuest(Guest guest){ guestRepository.save(guest);}

    @Override
    public void updateGuest(Guest guest){guestRepository.save(guest);}

    @Override
    public void deleteGuest(int id) {guestRepository.deleteById(id);}

    @Override
    public Guest getGuest(int id){return guestRepository.findById(id).get();}

    @Override
    public List<Guest> getAllGuest(){return guestRepository.findAll();}
}
