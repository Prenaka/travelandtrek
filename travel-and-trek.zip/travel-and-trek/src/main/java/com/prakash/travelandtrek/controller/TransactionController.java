package com.prakash.travelandtrek.controller;

import com.prakash.travelandtrek.model.Transaction;
import com.prakash.travelandtrek.service.TransactionServiceImpl;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/transactions")
@CrossOrigin(origins = "*")
public class TransactionController {
    private final TransactionServiceImpl transactionService;

    public TransactionController(TransactionServiceImpl transactionService){this.transactionService=transactionService;}

    @PostMapping
    public void saveTransaction(@RequestBody Transaction transaction) {
        transactionService.saveTransaction(transaction);
    }
    
    @PutMapping
    public void updateTransaction(@RequestBody Transaction transaction){transactionService.updateTransaction(transaction);}

    @DeleteMapping(value = "/{id}")
    public void deleteTransaction(@PathVariable int id){transactionService.deleteTransaction(id);}

    @GetMapping(value = "/{id}")
    public Transaction getTransaction(@PathVariable int id){return transactionService.getTransaction(id);}

    @GetMapping
    public List<Transaction> getAllTransaction(){return transactionService.getAllTransaction();}
}
