package com.prakash.travelandtrek.controller;

import com.prakash.travelandtrek.model.Reservation;
import com.prakash.travelandtrek.service.ReservationServiceImpl;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reservations")
@CrossOrigin(origins = "*")
public class ReservationController {
    private final ReservationServiceImpl reservationService;
    public ReservationController(ReservationServiceImpl reservationService) {this.reservationService=reservationService;}

    @PostMapping
    public void saveReservation(@RequestBody Reservation reservation){reservationService.saveReservation(reservation);}

    @PutMapping
    public void updateReservation(@RequestBody Reservation reservation){reservationService.updateReservation(reservation);}

    @DeleteMapping(value = "/{id}")
    public void deleteReservation(@PathVariable int id){reservationService.deleteReservation(id);}

    @GetMapping(value = "/{id}")
    public Reservation getReservation(@PathVariable int id){return reservationService.getReservation(id);}

    @GetMapping
    public List<Reservation> getAllReservation(){return reservationService.getAllReservation();}
}
