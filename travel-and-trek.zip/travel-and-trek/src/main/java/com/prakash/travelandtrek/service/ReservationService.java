package com.prakash.travelandtrek.service;

import com.prakash.travelandtrek.model.Reservation;

import java.util.List;

public interface ReservationService {
    void saveReservation(Reservation reservation);

    void updateReservation(Reservation reservation);

    void deleteReservation(int id);

    Reservation getReservation(int id);

    List<Reservation> getAllReservation();

}
