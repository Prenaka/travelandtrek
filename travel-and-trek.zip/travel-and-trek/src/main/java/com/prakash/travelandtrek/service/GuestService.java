package com.prakash.travelandtrek.service;

import com.prakash.travelandtrek.model.Guest;

import java.util.List;

public interface GuestService {
    void saveGuest(Guest guest);

    void updateGuest(Guest guest);

    void deleteGuest(int id);

    Guest getGuest(int id);

    List<Guest> getAllGuest();
}
