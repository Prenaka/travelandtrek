package com.prakash.travelandtrek;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelAndTrekApplicationTests {

    @Test
    void contextLoads() {
    }

}
